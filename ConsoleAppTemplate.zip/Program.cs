﻿using System;
using System.Collections.Generic;
using System.Linq;
using OCSS.Util.CmdLine;

// todo: add a nuget reference to the latest version of package: OCSS.Util.CmdLine

namespace $safeprojectname$ {

   class Program {

      // Todo: Add your command line parameters here
      private static readonly string FLAG1 = "1";
      private static readonly string FLAG2 = "2";

      static void Main(string[] args) {
         // Todo:
         // 1) Add your flags to the list
         // 2) Update the true/false flags depending on whether each parameter is required or not
         CmdFlag[] flags = { new CmdFlag(FLAG1, true), new CmdFlag(FLAG2, true)};
         var ret = ProcessCmd(flags, args);
         if (ret.HasError) {
            Console.WriteLine("Error: {0}", ret.ErrMsg);
         }
         else {
            // todo: main program execution here - successful command line processed and returned in variable ret
         }
         Console.WriteLine("Press <Enter> to exit program");
         Console.ReadLine();
      }

      private static CmdRet ProcessCmd(IEnumerable<CmdFlag> flagset, string[] args) {
         var ret = new CmdRet();
         CmdLine cmd = new CmdLine(flagset);
         if (cmd.ProcessCmdLine(args) == false) {
            // failed command-line arg requirements
            string errmsg = "Missing required command line switches: " + string.Join(", ", cmd.GetMissingSwitchesRequired().ToArray());
            return ReturnFail(errmsg);
         }
         // validate parameters now that all required flags are present
         // todo: assign each commmand line parameter to a property in CmdRet. Validate each as you go. On failed validation, return: ReturnFail(msg);
         // ex) ret.InFile = cmd.GetParm(FLAG_INFILE1);
         //     if (File.Exists(ret.InFile) == false)
         //        return ReturnFail($"Input file '{ret.InFile}' does not exist.");
         //

         // todo: check for, assign, and validate any optional parameters here
         // ex) if (cmd.ParmExists(FLAG_CASE_SENSITIVE))
         //        ret.CaseSensitive = true;
         return ret;    // successful return
      }

      private static CmdRet ReturnFail(string errMsg) {
         return new CmdRet { ErrMsg = "Error: " + errMsg };
      }

   }

   internal class CmdRet {
      //todo: Add other properties that you want to encapsulate and return. Typically, these will correspond one-to-one with the command line flags/parameters
      public string ErrMsg { get; set; }
      public bool HasError {  get { return ErrMsg != string.Empty; }  }

      public CmdRet() {
         ErrMsg = string.Empty;
         // todo: intialize your return structure
      }
   }

}
